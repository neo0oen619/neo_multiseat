﻿neo_multiseat gaming mouse package
=================================

This archive bundles the components required for neo_multiseat's virtual HID mouse support:

- driver/vmulti.inf, vmulti.sys, vmulti.cat — Virtual Multiple HID driver based on djpnewton/vmulti (https://github.com/djpnewton/vmulti).  Rebuilt with WDK 7.1 and test-signed for lab use (certificate: neo_multiseat test).
- driver/neo_multiseat_test.cer — import into LocalMachine\Root and LocalMachine\TrustedPublisher before installing the driver.
- host/host_agent.exe — UDP-to-VMulti bridge compiled from neo_multiseat sources.
- client/neo_client.exe — raw input UDP sender with interactive IP selection.

Usage summary
-------------
1. Import the certificate (admin shell):
   Import-Certificate -FilePath .\driver\neo_multiseat_test.cer -CertStoreLocation Cert:\LocalMachine\Root
   Import-Certificate -FilePath .\driver\neo_multiseat_test.cer -CertStoreLocation Cert:\LocalMachine\TrustedPublisher
2. Install the driver:
   pnputil /add-driver .\driver\vmulti.inf /install
3. Run neo_multiseat.ps1 option "Gaming mouse" to provision seat assets.

This package is intended for testing. For production, obtain a properly signed driver.
